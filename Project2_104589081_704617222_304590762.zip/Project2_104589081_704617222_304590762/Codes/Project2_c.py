# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 13:03:46 2016

@author: niulongjia
"""
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction import text
#from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
import nltk.stem
import re
import scipy
import numpy
import operator
import heapq

categories =['comp.sys.ibm.pc.hardware','comp.sys.mac.hardware','misc.forsale','soc.religion.christian']
train = fetch_20newsgroups(subset='train', categories=categories, shuffle=True, random_state= 42)
'''
train = fetch_20newsgroups(subset='train',shuffle=True, random_state= 42)
categories = train.target_names;
'''
# train_datas contain 2352 elements, each one is a string containing email content.
train_datas = train.data
# construct a english stemmedCountVectorizer that enhances CountVectorizer  
english_stemmer = nltk.stem.SnowballStemmer('english')
class StemmedCountVectorizer(CountVectorizer):
    def build_analyzer(self):
        analyzer = super(StemmedCountVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))
        
vectorizer = StemmedCountVectorizer(min_df=1, stop_words='english', decode_error='ignore')

# X is doc-term matrix
X = vectorizer.fit_transform(train_datas)
X = X.toarray()

# Y is class-term matrix
Y = numpy.zeros( (len(categories),len(X[0])) ) 

for i in range(len(X)):
    #print i
    sign = train.target[i]
    Y[sign] += X[i]

# Return 10 most significant terms
N=10
# Retrun 10 most significant terms for each class

# TF=0.5+0.5*f/fmax    
TF = numpy.zeros( (len(categories),len(Y[0])) ) 
for i in range(len(categories)):
    maxValue=float(Y[i].max())
    TF[i]=0.5*numpy.ones( (1,len(Y[0])) )+0.5*Y[i]/maxValue

# ICF=log|C|/|c|    
ICF = numpy.zeros( (1,len(X[0])) )
for j in range( len(Y[0]) ):
    ICF[0][j]=scipy.log(float(len(categories))/numpy.count_nonzero(Y[:,j]))

# TF*ICF
TFICF = TF*ICF


# sortedYIndex stores the indexes of ascending sorted array Y
sortedTFICFIndex=numpy.argsort(TFICF)
TenSignificantTerms_0=[]
TenSignificantTerms_1=[]
TenSignificantTerms_2=[]
TenSignificantTerms_3=[]
#print '      comp.sys.ibm.pc.hardware'
#print '      comp.sys.mac.hardware'
#print '      misc.forsale'
print '      soc.religion.christian'
for j in range(N):
    #print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[0][-1-j]])
    #print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[1][-1-j]])
    #print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[2][-1-j]])
    print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[3][-1-j]])
    TenSignificantTerms_0.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[0][-1-j]]) )
    TenSignificantTerms_1.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[1][-1-j]]) )
    TenSignificantTerms_2.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[2][-1-j]]) )
    TenSignificantTerms_3.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[3][-1-j]]) )

'''
# sortedYIndex stores the indexes of ascending sorted array Y
sortedTFICFIndex=numpy.argsort(TFICF)
TenSignificantTerms_3=[]
TenSignificantTerms_4=[]
TenSignificantTerms_6=[]
TenSignificantTerms_15=[]
print '      comp.sys.ibm.pc.hardware'
#print '      comp.sys.mac.hardware'
#print '      misc.forsale'
#print '      soc.religion.christian'
for j in range(N):
    print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[3][-1-j]])
    #print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[4][-1-j]])
    #print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[6][-1-j]])
    #print '      Rank '+str(j+1)+': '+str(vectorizer.get_feature_names()[sortedTFICFIndex[15][-1-j]])
    TenSignificantTerms_3.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[3][-1-j]]) )
    TenSignificantTerms_4.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[4][-1-j]]) )
    TenSignificantTerms_6.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[6][-1-j]]) )
    TenSignificantTerms_15.append( str(vectorizer.get_feature_names()[sortedTFICFIndex[15][-1-j]]) )

'''
'''
# return top 10 significant terms of the selected 4 class
# result contained in TenSignificantTerms_selected
print '\n'
indices = (-TFICF_selected).argpartition(N, axis=None)[:N]
MaxTFICF_x, MaxTFICF_y = numpy.unravel_index(indices, TFICF_selected.shape)
TenSignificantTerms_selected=[]
for i in range(N):
   print 'Rank_'+str(i)+' '+str(TFICF_selected[MaxTFICF_x[i]][MaxTFICF_y[i]])+' '+str(vectorizer.get_feature_names()[MaxTFICF_y[i]])
   TenSignificantTerms_selected.append( str(vectorizer.get_feature_names()[MaxTFICF_y[i]]) )
'''