# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 16:42:05 2016

@author: niulongjia
"""
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
import nltk.stem
import scipy
import numpy
from sklearn.linear_model import LogisticRegression
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve

categories_C =['comp.graphics','comp.os.ms-windows.misc','comp.sys.ibm.pc.hardware','comp.sys.mac.hardware']
categories_R =['rec.autos','rec.motorcycles', 'rec.sport.baseball' ,'rec.sport.hockey']
T_train= fetch_20newsgroups(subset='train', categories=categories_C+categories_R, shuffle=True, random_state= 42)
T_test= fetch_20newsgroups(subset='test', categories=categories_C+categories_R, shuffle=True, random_state= 42)

print 'T_train.data length: '+str(len(T_train.data))

# In[]
# considering stem and stopwords   
train_datas = T_train.data
test_datas = T_test.data
english_stemmer = nltk.stem.SnowballStemmer('english')

class StemmedTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(StemmedTfidfVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))

vectorizer = StemmedTfidfVectorizer(min_df=1, stop_words='english', decode_error='ignore')
# X_train is doc-term matrix
X_train = vectorizer.fit_transform(train_datas)
# X_test is doc-term matrix
X_test = vectorizer.transform(test_datas)
#X_train = X_train.toarray()
# 4732, 70065
num_samples_train, num_features = X_train.shape
print("Train doc-term after removing stemmed/stopped words #samples: %d, #features: %d" % (num_samples_train, num_features))
num_samples_test, num_features = X_test.shape
print("Test doc-term after removing stemmed/stopped words #samples: %d, #features: %d" % (num_samples_test, num_features))


# In[ ]:
k = 50

U_k,S_k,V_k = scipy.sparse.linalg.svds(X_train.T,k = k)
# D_k 50terms - documents
D_k_train = U_k.T * X_train.T # columns -- documents
D_k_test = U_k.T * X_test.T
# In[ ]:
# doc-50terms
Datas_train = D_k_train.T
Datas_test = D_k_test.T
# doc-class
labels_train = numpy.zeros( (num_samples_train,) )
for i in range(num_samples_train):
    if T_train.target[i]<=3:
        labels_train[i]=0 # computer technology
    else:
        labels_train[i]=1 # recreational activity

C = 0.1

TPR=[]
FPR=[]
Threshold=[]
clf = LogisticRegression(penalty='l2', dual=False, tol=0.0001, C=1.0,  solver='sag', max_iter=100)

clf.fit(Datas_train, labels_train)

labels_test_actual = numpy.zeros( (num_samples_test,) )
for i in range(num_samples_test):
    if T_test.target[i]<=3:
        labels_test_actual[i]=0 # computer technology
    else:
        labels_test_actual[i]=1 # recreational activity


labels_test_predicted = numpy.zeros( (num_samples_test,) )
TN,TP,FN,FP = 0,0,0,0
Sum = num_samples_test
for i in range(num_samples_test):
    labels_test_predicted[i]=clf.predict(Datas_test[i].reshape(1,-1))
    if labels_test_actual[i]==0 and labels_test_predicted[i]==0:
        TN += 1;
    if labels_test_actual[i]==0 and labels_test_predicted[i]==1:
        FP += 1;
    if labels_test_actual[i]==1 and labels_test_predicted[i]==0:
        FN += 1;
    if labels_test_actual[i]==1 and labels_test_predicted[i]==1:
        TP += 1;

#labels_test_predicted2=clf.predict(Datas_test)# same as labels_test_predicted
y_score=clf.fit(Datas_train, labels_train).decision_function(Datas_test)

fpr, tpr, _ = roc_curve(labels_test_actual, y_score)
plt.figure()
plt.plot(fpr, tpr)
plt.plot([0, 1], [0, 1], 'k--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve for Logistic Regression model')
plt.show()
plt.savefig('ROC curve for Logistic Regression model.png')
TPR = float(TP)/(TP+FN)
FPR = float(FP)/(TN+FP)
Recall = float(TP)/(TP+FN)
Accuracy=float((TP+TN))/Sum
Precision = float(TP)/(TP+FP)

print 'TPR: '+str(TPR)
print 'FPR: '+str(FPR)
print 'Recall: '+str(Recall)
print 'Accuracy: '+str(Accuracy)
print 'Precision: '+str(Precision)

# compute confusion matrix
from sklearn import metrics
from sklearn.metrics import confusion_matrix

def plot_confusion_matrix(cm, title='Confusion matrix', cmap=plt.cm.Blues):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    #tick_marks = np.arange(len(iris.target_names))
    tick_marks = numpy.arange(2)
    plt.xticks(tick_marks, ['Computer technology', 'Recreational activity'], rotation=45)
    plt.yticks(tick_marks, ['Computer technology', 'Recreational activity'])
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


# Compute confusion matrix
cm = confusion_matrix(labels_test_actual, labels_test_predicted)
numpy.set_printoptions(precision=2)
print('Confusion matrix, without normalization')
print(cm)
plt.figure()
plot_confusion_matrix(cm)

# Normalize the confusion matrix by row (i.e by the number of samples
# in each class)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, numpy.newaxis]
print('Normalized confusion matrix')
print(cm_normalized)
plt.figure()
plot_confusion_matrix(cm_normalized, title='Normalized confusion matrix')
plt.show()

print(metrics.classification_report(labels_test_actual, labels_test_predicted,target_names=report_categories))
