# -*- coding: utf-8 -*-
"""
Created on Tue Feb 16 23:27:53 2016

@author: Xinxin
"""
from sklearn.datasets import fetch_20newsgroups

trainset = fetch_20newsgroups(subset = 'train',shuffle = True, random_state = 42)
testset = fetch_20newsgroups(subset = 'test',shuffle = True, random_state = 42)

import numpy as np
import matplotlib.pyplot as plt
# before samle
list_name = []
list_size = []
list_target = list(trainset.target)
for t in np.unique(list_target):
    print 'The number of ' + trainset.target_names[t] +' is: '
    print list_target.count(t)
    list_name.append(trainset.target_names[t])
    list_size.append(list_target.count(t))
index = np.arange(20)
bar_width = 0.3
plt.barh(index,list_size,facecolor='b',alpha=0.3) 
plt.title('Number of Documents Per Topic')
plt.yticks(index + bar_width, list_name)
plt.xlabel('number')
plt.show()
list_CT = ['comp.graphics', 'comp.os.ms-windows.misc', 'comp.sys.ibm.pc.hardware', 'comp.sys.mac.hardware']
list_RA = ['rec.autos', 'rec.motorcycles', 'rec.sport.baseball', 'rec.sport.hockey']
num_RA = 0
num_CT = 0
num_CT = sum(list_size[1:4])
num_RA = sum(list_size[7:10])

print 'Number of Computer technology is ' +str(num_CT)
print 'Number of Recreational activity is ' +str(num_RA)