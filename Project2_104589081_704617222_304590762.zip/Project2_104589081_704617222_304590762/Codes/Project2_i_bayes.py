
# coding: utf-8

# In[1]:

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction import text
from sklearn.naive_bayes import MultinomialNB
from sklearn import preprocessing

import nltk.stem
from sklearn.svm import SVC
from sklearn import metrics
import matplotlib.pyplot as plt
import scipy as sc
import numpy as np

categories =['comp.sys.ibm.pc.hardware' , 'comp.sys.mac.hardware', 'misc.forsale', 'soc.religion.christian']
T_train= fetch_20newsgroups(subset='train', categories=categories, shuffle=True, random_state= 42)
T_test= fetch_20newsgroups(subset='test', categories=categories, shuffle=True, random_state= 42)


stop_words = text.ENGLISH_STOP_WORDS
test_data=T_train.data
english_stemmer = nltk.stem.SnowballStemmer('english')

class StemmedTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(StemmedTfidfVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))

vectorizer = StemmedTfidfVectorizer(
    min_df=1, stop_words='english', decode_error='ignore')
#transform train set
X_train = vectorizer.fit_transform(test_data)
num_samples, num_features = X_train.shape
print("#samples: %d, #features: %d" % (num_samples, num_features))

k = 50
U_k,S_k,V_k = sc.sparse.linalg.svds(X_train.T,k = k)
Dk_X_train = U_k.T * X_train.T # columns -- documents
y_train = T_train.target

# transform the test set
X_test = vectorizer.transform(T_test.data)
Dk_X_test = U_k.T * X_test.T # columns -- documents
print Dk_X_test.shape
y_test = T_test.target
print 'y_test: ' + str(y_test)


# In[13]:

min_max_scaler = preprocessing.MinMaxScaler()
X_train = min_max_scaler.fit_transform(Dk_X_train.T)
X_test = min_max_scaler.transform(Dk_X_test.T)         
   


# In[14]:

#Naive Bayes  model
from sklearn.naive_bayes import GaussianNB
gnb = GaussianNB()
y_pred = gnb.fit(X_train, y_train).predict(X_test)
print y_pred

print(metrics.classification_report(y_test, y_pred,target_names=categories))
print metrics.confusion_matrix(y_test, y_pred)
print metrics.accuracy_score(y_test, y_pred)


# In[11]:

min_max_scaler = preprocessing.MinMaxScaler()
X_train = min_max_scaler.fit_transform(Dk_X_train.T)
X_test = min_max_scaler.transform(Dk_X_test.T)
from sklearn.naive_bayes import MultinomialNB
mnb = MultinomialNB()
y_pred2 = mnb.fit(X_train, y_train).predict(X_test)
print(metrics.classification_report(y_test, y_pred2,target_names=categories))
print metrics.confusion_matrix(y_test, y_pred2)
print metrics.accuracy_score(y_test, y_pred2)


# In[17]:

def plot_confusion_matrix(cm, title='Confusion matrix', cmap=plt.cm.Blues):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    #tick_marks = np.arange(len(iris.target_names))
    tick_marks = np.arange(4)
    plt.xticks(tick_marks, categories, rotation=45)
    plt.yticks(tick_marks, categories)
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


# Compute confusion matrix
cm = metrics.confusion_matrix(y_test, y_pred)
np.set_printoptions(precision=2)
print('Confusion matrix, without normalization')
print(cm)
plt.figure()
plot_confusion_matrix(cm)

# Normalize the confusion matrix by row (i.e by the number of samples
# in each class)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
print('Normalized confusion matrix')
print(cm_normalized)
plt.figure()
plot_confusion_matrix(cm_normalized, title='Normalized confusion matrix')
plt.show()


# In[ ]:



