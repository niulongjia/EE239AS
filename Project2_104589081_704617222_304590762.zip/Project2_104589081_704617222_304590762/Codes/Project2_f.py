
# coding: utf-8

# In[1]:

#part f find best parameter gamma
#reset the parameter in e with best gamma 
#use the same code as part e to test in test set, plot ROC and report result
from __future__ import division 
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction import text
from sklearn import grid_search
import nltk.stem
from sklearn.metrics import roc_curve
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import scipy as sc

report_categories = ['Computer technology','Recreational activity']
categories_C =['comp.graphics','comp.os.ms-windows.misc','comp.sys.ibm.pc.hardware','comp.sys.mac.hardware']
categories_R =['rec.autos','rec.motorcycles', 'rec.sport.baseball' ,'rec.sport.hockey']
T_train= fetch_20newsgroups(subset='train', categories=categories_C+categories_R, shuffle=True, random_state= 42)


stop_words = text.ENGLISH_STOP_WORDS
english_stemmer = nltk.stem.SnowballStemmer('english')

class StemmedTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(StemmedTfidfVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))

vectorizer = StemmedTfidfVectorizer(
    min_df=1, stop_words='english', decode_error='ignore')

#merge 8 subclasses to 2 classes    
import numpy as np
TB_target = [];
for doc in T_train.target:
    if T_train.target_names[doc] in categories_C :
        TB_target.append(0);
    else:
        TB_target.append(1);

from sklearn import svm
from sklearn.cross_validation import KFold
from sklearn import preprocessing
from sklearn import metrics

#define class 0 is positive, class 1 is negative
TF = 0 #num of doc that predicted in 1 and really in 1
TP = 0 #num of doc that predicted in 0 and really in 0
FN = 0 #num of doc that predicted in 1 and really in 0
FP = 0 #num of doc that predicted in 0 and really in 1
f5 = KFold(len(T_train.data), n_folds=5, shuffle=True, random_state=None)

k = 50
import numpy as np
l_f_acc = []
l_f_pre = []
l_f_recall = []
for i in range(-3,4):
    l_recall = []
    l_prec = []
    l_accu = []
    penalty = 10 ** i
    print '-----------------penalty: ' + str(penalty) +' start------------------'
    #Precision = TP / (TP+FP) Recall = TP / (TP+FN) Accuracy = (TP + TN) / (TP + TN + FP + FN)
    for train_index, test_index in f5:
        X_train = []
        X_test = []
        y_train = []
        y_test = []
        for x in train_index:
            X_train.append(T_train.data[x])
        for x in test_index:
            X_test.append(T_train.data[x])
        for x in train_index:
            y_train.append(TB_target[x])
        for x in test_index:
            y_test.append(TB_target[x])
    #    X_train, X_test = train_data[train_index], train_data[test_index]
    #    y_train, y_test = train_target[train_index], train_target[test_index]
        
        # get Dk for train
        tX_train = vectorizer.fit_transform(X_train)
        print tX_train.shape
        U_k,S_k,V_k = sc.sparse.linalg.svds(tX_train.T,k = k)
        Dk_X_train = U_k.T * tX_train.T
        print 'DK train done'
        
        #get Dk fot test
        tX_test = vectorizer.transform(X_test)
        print tX_test.shape
        #U_kt,S_kt,V_kt = sc.sparse.linalg.svds(tX_test.T,k = k)
         # columns -- documents
        Dk_X_test = U_k.T * tX_test.T
        print 'Dk test done'
        
        #build classifier
        #clf2 = svm.SVC(kernel = 'rbf', C = penalty)
        #clf2.fit(Dk_X_train.T,y_train)
        # prediction
        #y_pre = clf2.predict(Dk_X_test.T)
        #Dk_X_train = preprocessing.scale(Dk_X_train.T)
        #Dk_X_test = preprocessing.scale(Dk_X_test.T)
        #clf2 = svm.SVC(kernel = 'linear', C = penalty)
        #clf2.fit(Dk_X_train.T,y_train)
        # prediction
        #y_pre = clf2.predict(Dk_X_test.T)
        y_pre = svm.SVC(kernel = 'rbf', C = penalty).fit(Dk_X_train.T,y_train).predict(Dk_X_test.T)
    
        print y_pre.shape
        print 'predict done'
        
        #calculate recall precision accurancy
        n_total = len(y_test) # total number of test
        print 'total: '+ str(n_total)
        #n_N_real = sum(y_test-1) # = TN+FP : total number of doc really in class 1 (negative)
        #n_p_real = n_total - n_N_real # = TP+FN total number of doc really in class 0 (positive)
        y_delta = np.array(y_pre)-np.array(y_test)
        #print y_delta
        FP = y_delta.tolist().count(-1) # if y_delta(i) = -1, then predict in 0 but really in 1
        FN = y_delta.tolist().count(1) # if y_delta(i) = 1, then predict in 1 but really in 0
        print FP,FN
        n_N_pre = sum(np.array(y_pre)) # total number of doc predicted in class 1 (negative)
        n_P_pre = n_total - n_N_pre # total number of doc predicted in class 0 (positive)
        print n_P_pre, n_N_pre
        TP = n_P_pre - FP
        TN = n_N_pre - FN
        print TP,TN
        #recall = TP/(TP+FN)
        #precision = TP/(TP+FP)
        #accurancy = (TP+TN)/n_total
        accurancy = metrics.accuracy_score(y_test,y_pre)
        precision = metrics.precision_score(y_test, y_pre)
        recall = metrics.recall_score(y_test, y_pre)
        print 'recall: ' + str(recall) + ' precision:'+ str(precision) + ' accurancy: '+str(accurancy)
        l_recall.append(recall)
        l_prec.append(precision)
        l_accu.append(accurancy)
        #print clf2.score(Dk_X_test.T,np.array(y_test))
        print(metrics.classification_report(y_test, y_pre,target_names=report_categories))
        print metrics.confusion_matrix(y_test, y_pre)
        print '--------------------------------------'
    # get average precision recall anf accurancy
    f_prec = np.array(l_prec).mean()
    f_recall = np.array(l_recall).mean()
    f_accu = np.array(l_accu).mean()
    print f_prec
    print f_recall
    print f_accu
    l_f_pre.append(f_prec)
    l_f_recall.append(f_recall)
    l_f_acc.append(f_accu)
    print '---------------------penalty = ' +str(penalty)+' done -------------------------'

print l_f_acc


# In[ ]:



