
# coding: utf-8

# In[2]:




# In[2]:

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction import text
import nltk.stem
from sklearn.svm import SVC
from sklearn.metrics import roc_curve
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import scipy as sc
import numpy as np


from sklearn.preprocessing import label_binarize
from sklearn.multiclass import OneVsOneClassifier
from sklearn.multiclass import OneVsRestClassifier
categories =['comp.sys.ibm.pc.hardware','comp.sys.mac.hardware','misc.forsale','soc.religion.christian']
train = fetch_20newsgroups(subset='train', categories=categories, shuffle=True, random_state= 42)
test= fetch_20newsgroups(subset='test', categories=categories, shuffle=True, random_state= 42)
# train_datas contain 2352 elements, each one is a string containing email content.
train_datam = train.data
test_datam=test.data
# construct a english stemmedCountVectorizer that enhances CountVectorizer  
english_stemmer = nltk.stem.SnowballStemmer('english')
class StemmedTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(StemmedTfidfVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))
        
vectorizer = StemmedTfidfVectorizer(min_df=1, stop_words='english', decode_error='ignore')
# do I need to use the 50 features??
X_trainm = vectorizer.fit_transform(train_datam)
num_samples, num_features = X_trainm.shape
print("#samples: %d, #features: %d" % (num_samples, num_features))
X_testm = vectorizer.transform(test_datam)


k = 50
U_km,S_km,V_km = sc.sparse.linalg.svds(X_trainm.T,k = k)
D_km = U_km.T * X_trainm.T # columns -- documents
D_kmt = U_km.T * X_testm.T # columns -- documents


#the total number of each class in the training set

list_name = []
list_size = []
trainset=train
list_target = list(trainset.target)
for t in np.unique(list_target):
    print 'The number of ' + trainset.target_names[t] +' is: '
    print list_target.count(t)
    list_name.append(trainset.target_names[t])
    list_size.append(list_target.count(t))
index = np.arange(4)
bar_width = 0.3
plt.barh(index,list_size,facecolor='b',alpha=0.3) 
plt.title('Number of Documents Per Topic')
plt.yticks(index + bar_width, list_name)
plt.xlabel('number')
plt.show()
# In[5]:

#print list(train.target)
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn import metrics
y=train.target
#m=MultiLabelBinarizer().fit_transform(y)
test_res=OneVsRestClassifier(SVC(C=0.001, cache_size=200, class_weight=None, coef0=0.0,decision_function_shape=None, degree=3, gamma='auto', kernel='rbf',
    max_iter=-1, probability=False, random_state=None, shrinking=True,tol=0.001, verbose=False)).fit(D_km.T, y).predict(D_kmt.T)
from sklearn.svm import LinearSVC
test_res2=OneVsOneClassifier(LinearSVC(random_state=0)).fit(D_km.T, y).predict(D_kmt.T)
print(metrics.classification_report(test.target, test_res2,
    target_names=test.target_names))
print confusion_matrix(test.target, test_res2)


# In[19]:

from sklearn.multiclass import OutputCodeClassifier
test_res3 = OutputCodeClassifier(LinearSVC(random_state=0),code_size=3, random_state=0).fit(D_km.T, y).predict(D_kmt.T)
print(metrics.classification_report(test.target, test_res3,
    target_names=test.target_names))
print confusion_matrix(test.target, test_res3)


# In[8]:

print(metrics.classification_report(test.target, test_res,
    target_names=test.target_names))
print confusion_matrix(test.target, test_res)


# In[10]:


#confusion matrix
#y_pre= test_res2
y_pre= test_res
y_test=test.target

def plot_confusion_matrix(cm, title='Confusion matrix', cmap=plt.cm.Blues):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    #tick_marks = np.arange(len(iris.target_names))
    tick_marks = np.arange(4)
    plt.xticks(tick_marks, categories, rotation=45)
    plt.yticks(tick_marks, categories)
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


# Compute confusion matrix
cm = confusion_matrix(y_test, y_pre)
np.set_printoptions(precision=2)
print('Confusion matrix, without normalization')
print(cm)
plt.figure()
plot_confusion_matrix(cm)

# Normalize the confusion matrix by row (i.e by the number of samples
# in each class)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
print('Normalized confusion matrix')
print(cm_normalized)
plt.figure()
plot_confusion_matrix(cm_normalized, title='Normalized confusion matrix')
plt.show()


# In[ ]:





# In[3]:

trainset=train
list_target = list(trainset.target)
col=('r','b','g','y')
for t in range(0,4):
    x=[];
    y=[];
    for tts in range(0,len(trainset.data)):
        if(train.target[tts]==t): 
             x.append(D_km.T[tts,1])
             y.append(D_km.T[tts,2]);   
    plt.figure(1)
    plt.scatter(x, y, c=col[t], cmap=plt.cm.Paired,label=test.target_names[t])
plt.legend();
plt.title('the first two features for different classes')
plt.xlabel('the first feature')
plt.xlabel('the second feature')
plt.show()
#plt.savefig('ovo.png')


# In[ ]:



