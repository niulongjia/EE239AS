
# coding: utf-8

# In[3]:

#multiclass classification

# -*- coding: utf-8 -*-
"""
Created on Sat Feb 20 22:38:00 2016

@author: Qiujing
"""
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction import text
import nltk.stem
from sklearn.svm import SVC
from sklearn.metrics import roc_curve
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import scipy as sc
import numpy as np
from sklearn import metrics

categories_C =['comp.graphics','comp.os.ms-windows.misc','comp.sys.ibm.pc.hardware','comp.sys.mac.hardware']
categories_R =['rec.autos','rec.motorcycles', 'rec.sport.baseball' ,'rec.sport.hockey']
T_train= fetch_20newsgroups(subset='train', categories=categories_C+categories_R, shuffle=True, random_state= 42)
T_test= fetch_20newsgroups(subset='test', categories=categories_C+categories_R, shuffle=True, random_state= 42)


stop_words = text.ENGLISH_STOP_WORDS
test_data=T_train.data
english_stemmer = nltk.stem.SnowballStemmer('english')

class StemmedTfidfVectorizer(TfidfVectorizer):
    def build_analyzer(self):
        analyzer = super(StemmedTfidfVectorizer, self).build_analyzer()
        return lambda doc: (english_stemmer.stem(w) for w in analyzer(doc))

vectorizer = StemmedTfidfVectorizer(
    min_df=1, stop_words='english', decode_error='ignore')

X_train = vectorizer.fit_transform(test_data)
num_samples, num_features = X_train.shape
print("#samples: %d, #features: %d" % (num_samples, num_features))


k = 50
U_k,S_k,V_k = sc.sparse.linalg.svds(X_train.T,k = k)
D_k = U_k.T * X_train.T # columns -- documents


TB_target = [];
for doc in T_train.target:
    if T_train.target_names[doc] in categories_C :
        TB_target.append(0);
    else:
        TB_target.append(1);
# transform the test set
X_test = vectorizer.transform(T_test.data)
#print X_test.shape
D_kt = U_k.T * X_test.T # columns -- documents
print D_kt.shape

TB_test_target = [];
for doc in T_test.target:
    if T_test.target_names[doc] in categories_C :
        TB_test_target.append(0);
    else:
        TB_test_target.append(1);

        
        
#SCV   model    

SVC(C=0.00001, cache_size=200, class_weight=None, coef0=0.0,
    decision_function_shape=None, degree=3, gamma='auto', kernel='rbf',
    max_iter=-1, probability=False, random_state=None, shrinking=True,
    tol=0.001, verbose=False)
clf = SVC()
clf.fit(D_k.T, TB_target) 

print sum(abs(clf.predict(D_kt.T)-TB_test_target))
#plot ROC
#clf is my SVM model,D_k.T is the training data,D_kt is the test data
#y_test=clf.predict(D_kt.T)
y_score=clf.fit(D_k.T, TB_target).decision_function(D_kt.T)
fpr, tpr, _ = roc_curve(TB_test_target, y_score)
plt.figure()
plt.plot(fpr, tpr)
plt.plot([0, 1], [0, 1], 'k--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve for SVM model')
plt.show()
plt.savefig('ROC curve for SVM model.png')


#confusion matrix
y_pre=clf.predict(D_kt.T)
y_test=TB_test_target

def plot_confusion_matrix(cm, title='Confusion matrix', cmap=plt.cm.Blues):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    #tick_marks = np.arange(len(iris.target_names))
    tick_marks = np.arange(2)
    plt.xticks(tick_marks, ['Computer technology', 'Recreational activity'], rotation=45)
    plt.yticks(tick_marks, ['Computer technology', 'Recreational activity'])
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')


# Compute confusion matrix
cm = confusion_matrix(y_test, y_pre)
np.set_printoptions(precision=2)
print('Confusion matrix, without normalization')
print(cm)
plt.figure()
plot_confusion_matrix(cm)

# Normalize the confusion matrix by row (i.e by the number of samples
# in each class)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
print('Normalized confusion matrix')
print(cm_normalized)
plt.figure()
plot_confusion_matrix(cm_normalized, title='Normalized confusion matrix')
plt.show()


# In[4]:

print(metrics.classification_report(y_test, y_pre,
    target_names=['Computer technology', 'Recreational activity']))

