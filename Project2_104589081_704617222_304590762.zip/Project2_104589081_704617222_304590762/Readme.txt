---Project2_a
plot the distribution of documents in different categories

---Project2_bd
Create TF-IDF vector representations and apply LSI to TF-IDF

---Project2_c
TF-ICF to extract top 10 significant terms for each class

---project2_e_svm.py
use the rbf kernel with c=1000 to simulate the hard margin SVM. There are ROC curve and confusion matrix shown as figures.

---Project2_f
soft Margin SVM

---Project2_g
Gaussian naive bayes

---Project2_h
Logistic Regression naive bayes

---Project2_i_bayes
Naive Bayes for Muticlass Classification

---Project2_i_SVM1.py
use one-vs-one classifier and one-vs-the-rest classifier, OutputCodeClassifier to do the classification.
plot the distribution of the first and second features of testing dataset for analysis.

